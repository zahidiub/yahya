<?php
// Heading
$_['heading_title']  = 'Aquma Control Panel';

// Text
$_['text_module']         = 'Modules';
$_['text_success']        = 'Success: You have modified Aquma theme!';

// Error
$_['error_permission']    = 'Warning: You do not have permission to modify!';

$_['text_image_manager'] = 'Image Manager';
$_['text_browse']        = 'Browse Files';
$_['text_clear']         = 'Clear Image';

?>